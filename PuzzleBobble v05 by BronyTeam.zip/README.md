###Puzzle Bobble v0.5
By Brony Team:
	- Marc Torres
	- Pau Oliv�
	- Andreu Sacasas
	- Carlos Martinez

This is a puzzle game where the player must aim and shoot bubbles in order to pop all the bubbles in the screen.
Bubbles pop when 3 or more are sticked together and the player looses if they arrive to the deadline on the bottom of the stage.

//---
  Instructions-><br />
	'a' to shoot bubbles <br />
	'left/right' to aim arrow <br />
	'space' to change from the main menu to the playable stage <br />

//---

  NOTES:
     Shooted Bubbles bounce when colliding to the walls.
     Bubbles stick to other bubbles and the ceiling.
     The player loses if the bubbles reach the deadline at the bottom.
     The player wins if all bubbles are removed from the stage.
     Bubbles should pop when 3 or more are stick together but still in progress (they will pop if 2 of the same color are together but they will not start a chained pop reaction).
     This feature still has some bugs, we are working on it to solve them.

####CHANGELIST
v0.5 -> Added All Bubbles on the screen + bubbles collide and stick to the rest + Win/Lose condition and screen + some sfx and musics fo every stage +   
   popping bubbles (Still in progress, not refined)

v0.4 -> Added Collisions to walls +  bouncing bubbles shoot.

v0.3 -> Added particles and player movement (rotating arrow)

v0.2 -> Fading changing stages + 'Main Menu' screen

v0.1 -> Created game window and showing Background